#include <iostream>
#include <cstring>
#include <stdlib.h>
#include <time.h>
using namespace std;

int kolle_system(int x);
int new_function(int i,int j);
int player_function(int i);
int team_function(int j);
int buy_function(int i,int j);
int sell_function(int i,int j);
int friendlyMatch_function(int j);
int match_function(int i,int j,int ran,int teamID1,int teamID2);
int BeginLeague_function(int i,int j,int l);

struct footbalist{
    char name[20];
    int price;
    int speed;
    int finishing;
    int defence;
    int code;
    int codeteambazikon;
    int zoj_ya_fard_boodan_sorate_hafbak;
    char post[20];
}footbalista[100];

struct team{
    char name[20];
    int money;
    int code;
    int tedadaza;
    int emtiaz;
    int tedadgolhaye_zadeshode;
    int tedadgolhaye_khordeshode;
    int tedad_bord;
    int tedad_bakht;
    int tedad_mosavi;
    int tafazol_golhayekhordeshode_ba_golhayezadeshode;
    int code_neshane_bara_takmile_11nafareboodan;
}teamha[100];

int main() {
    kolle_system(1);
    return 0;
}

int kolle_system(int x) {
    int i = 1, j = 1, l = 1;
    while (x) {
        char voroodieyek[10];
        cin >> voroodieyek;
        if (strcmp(voroodieyek, "new") == 0) {
            int zakhiree=new_function(i, j);
            if(zakhiree==1){
                i++;
            }
            else if(zakhiree==2){
                j++;
            }
        }
        if (strcmp(voroodieyek,"buy") == 0) {
            buy_function(i, j);
        }
        if (strcmp(voroodieyek, "sell") == 0) {
            sell_function(i, j);
        }
        if (strcmp(voroodieyek, "friendlyMatch") == 0) {
            friendlyMatch_function(j);
        }
        if (strcmp(voroodieyek, " ") == 0) {

        }
        if (strcmp(voroodieyek, "end") == 0) {
            return 2;
        }
        if(strcmp(voroodieyek, "Match") == 0){
            srand(time(0));
            int adaderandom_baraye_abohava = rand()%4+1;
            //1=abri.2=barfi.3=aftabi.4=barani.
            int teamID1=0,teamID2=0;
            cin>>teamID1>>teamID2;
            match_function(i,j,adaderandom_baraye_abohava,teamID1,teamID2);
        }
        if(strcmp(voroodieyek, "BeginLeague") == 0){
            BeginLeague_function(i,j,l);
        }
    }
    return 1;
}
int new_function(int i,int j){
    char voroodiedo[10]="a";
    cin >> voroodiedo;
    if (strcmp(voroodiedo, "player") == 0) {
        player_function(i);
        return 1;
    }
    if (strcmp(voroodiedo, "team") == 0) {
        int barresi=team_function(j);
        if(barresi==1){
            return 2;
        }
        else{
            return 3;
        }
    }
    return 3;
}

int player_function(int i){
    footbalista[i].code = i;
    cin >> footbalista[i].name;
    cin >> footbalista[i].price;
    cin >> footbalista[i].speed;
    cin >> footbalista[i].finishing;
    cin >> footbalista[i].defence;
    footbalista[i].codeteambazikon=0;
    if(footbalista[i].speed>footbalista[i].finishing & footbalista[i].speed>footbalista[i].defence){
        strcpy(footbalista[i].post,"hafbak");
        if(footbalista[i].speed%2==0){
            footbalista[i].zoj_ya_fard_boodan_sorate_hafbak=2;
        }
        else if(footbalista[i].speed%2==1){
            footbalista[i].zoj_ya_fard_boodan_sorate_hafbak=1;
        }
    }
    else if(footbalista[i].defence>footbalista[i].finishing  & footbalista[i].defence>footbalista[i].speed){
        strcpy(footbalista[i].post,"modafe");
    }
    else if(footbalista[i].finishing>footbalista[i].defence  & footbalista[i].finishing>footbalista[i].speed){
        strcpy(footbalista[i].post,"mohajem");
    }
    else if(footbalista[i].finishing==footbalista[i].defence  & footbalista[i].finishing==footbalista[i].speed & footbalista[i].speed==footbalista[i].defence){
        strcpy(footbalista[i].post,"normal");
    }
    else{
        strcpy(footbalista[i].post,"namoshakhas");
    }
    return 1;
}

int team_function(int j){
    char teamname[20]="a";
    cin >> teamname;
    int alamat = 0;
    for (int k = 1; k < j; k++) {
        if (strcmp(teamname,teamha[k].name) == 0)
            alamat = 1;
    }
    if (alamat == 0) {
        strcpy(teamha[j].name, teamname);
        cin >> teamha[j].money;
        teamha[j].code = j;
        teamha[j].tedadaza=0;
        teamha[j].emtiaz=0;
        teamha[j].tedadgolhaye_zadeshode=0;
        teamha[j].tedadgolhaye_khordeshode=0;
        teamha[j].tedad_bord=0;
        teamha[j].tedad_mosavi=0;
        teamha[j].tedad_bakht=0;
        teamha[j].tafazol_golhayekhordeshode_ba_golhayezadeshode=0;
        teamha[j].code_neshane_bara_takmile_11nafareboodan=0;
        return 1;
    }
    else{
        return 2;
    }
}

int friendlyMatch_function(int j){
    int teamID1=0, teamID2=0;
    cin >> teamID1 >> teamID2;
    int neshoone = 0;
    for (int x = 1; x < j; x++) {
        if (teamha[x].code == teamID1) {
            neshoone = 1;
        }
    }
    if (neshoone == 0) {
        cout << "team doesnt exist" << endl;
    }
    else {
        neshoone = 0;
        for (int x = 1; x < j; x++) {
            if (teamha[x].code == teamID2) {
                neshoone = 1;
            }
        }
        if (neshoone == 0) {
            cout << "team doesnt exist" << endl;
        }
        else {
            if (teamha[teamID1].tedadaza != 11 | teamha[teamID2].tedadaza != 11) {
                cout << "the game can not be held due to loss of the players" << endl;
            }
            else {
                long int powerofteameyek = 0, powerofteamedo = 0;
                for (int k = 1; k < 100; k++) {
                    if (footbalista[k].codeteambazikon == teamID1) {
                        powerofteameyek = powerofteameyek + footbalista[k].speed + footbalista[k].finishing +
                                          footbalista[k].defence;
                    }
                }
                for (int k = 1; k < 100; k++) {
                    if (footbalista[k].codeteambazikon == teamID2) {
                        powerofteamedo = powerofteamedo + footbalista[k].speed + footbalista[k].finishing +
                                         footbalista[k].defence;
                    }
                }
                if (powerofteameyek == powerofteamedo) {
                    cout << "the match is draw" << endl;
                }
                else if (powerofteameyek > powerofteamedo) {
                    cout << "team " << teamID1 << " win" << endl;
                }
                else if (powerofteameyek < powerofteamedo) {
                    cout << "team " << teamID2 << " win" << endl;
                }
            }
        }
    }
    return 1;
}

int buy_function(int i,int j){
    int playerID=0, teamID=0;
    cin >> playerID >> teamID;
    int alamateyek = 1;
    for (int k = 1; k < i; k++) {
        if (footbalista[k].code == playerID) {
            alamateyek = 0;
        }
    }
    if (alamateyek == 1) {
        cout << "player with the id playerID doesnt exist " << endl;
    }
    else {
        alamateyek = 1;
        for (int k = 1; k < j; k++) {
            if (teamha[k].code == teamID) {
                alamateyek = 0;
            }
        }
        if (alamateyek == 1) {
            cout << "team with the id teamID doesnt exist"<<endl;
        }
        else {
            if (teamha[teamID].money < footbalista[playerID].price) {
                cout << "the team cant afford to buy this player"<<endl;
            }
            else {
                if (footbalista[playerID].codeteambazikon != 0) {
                    cout << "player already has a team"<<endl;
                }
                else {
                    if (teamha[teamID].tedadaza==11) {
                        cout << "team is full"<<endl;
                    }
                    else {
                        cout << "player " << playerID << " added to the team " << teamID << " successfully" << endl;
                        footbalista[playerID].codeteambazikon = teamID;
                        teamha[teamID].money = teamha[teamID].money - footbalista[playerID].price;
                        teamha[teamID].tedadaza=(teamha[teamID].tedadaza)+1;
                    }
                }
            }
        }
    }
    return 1;
}

int sell_function(int i,int j){
    int playerID=0, teamID=0;
    cin >> playerID >> teamID;
    int alamatedo = 1;
    for (int k = 1; k < j; k++) {
        if (teamha[k].code == teamID) {
            alamatedo = 0;
        }
    }
    if (alamatedo == 1) {
        cout << "team doesnt exist" << endl;
    }
    else {
        alamatedo = 1;
        int zakhirecodebazikon = 0;
        for (int k = 1; k < i; k++) {
            if (footbalista[k].codeteambazikon == teamha[teamID].code) {
                alamatedo = 0;
                zakhirecodebazikon = k;
            }
        }
        if (alamatedo == 1) {
            cout << "team doesnt have this player" << endl;
        }
        else {
            footbalista[zakhirecodebazikon].codeteambazikon = 0;
            teamha[teamID].tedadaza = teamha[teamID].tedadaza - 1;
            teamha[teamID].money = teamha[teamID].money + footbalista[zakhirecodebazikon].price;
            cout << "player " << playerID << " removed from the team " << teamID << " successfully" << endl;
        }
    }
    return 1;
}
int match_function(int i,int j,int ran,int teamID1,int teamID2){
    int gollteam1=0,gollteam2=0;
    int neshoone = 0;
    for (int x = 1; x < j; x++) {
        if (teamha[x].code == teamID1) {
            neshoone = 1;
        }
    }
    if (neshoone == 0) {
        cout << "team doesnt exist" << endl;
    }
    else {
        neshoone = 0;
        for (int x = 1; x < j; x++) {
            if (teamha[x].code == teamID2) {
                neshoone = 1;
            }
        }
        if (neshoone == 0) {
            cout << "team doesnt exist" << endl;
        }
        else {
            if (teamha[teamID1].tedadaza != 11 | teamha[teamID2].tedadaza != 11) {
                cout << "the game can not be held due to loss of the players" << endl;
            }
            else {
                if(ran==2){
                    for(int k=1;k<i;k++){
                        if(footbalista[k].codeteambazikon==teamha[teamID1].code){
                            if(strcmp(footbalista[k].post,"modafe")==0){
                                footbalista[k].defence=footbalista[k].defence-footbalista[k].defence-footbalista[k].defence;
                            }
                        }
                    }

                    for(int k=1;k<i;k++){
                        if(footbalista[k].codeteambazikon==teamha[teamID2].code){
                            if(strcmp(footbalista[k].post,"modafe")==0){
                                footbalista[k].defence=footbalista[k].defence-footbalista[k].defence-footbalista[k].defence;
                            }
                        }
                    }
                }
                else if(ran==3){
                    for(int k=1;k<i;k++){
                        if(footbalista[k].codeteambazikon==teamha[teamID1].code){
                            if(strcmp(footbalista[k].post,"mohajem")==0){
                                footbalista[k].finishing=footbalista[k].finishing-10;
                            }
                        }
                    }
                    for(int k=1;k<i;k++){
                        if(footbalista[k].codeteambazikon==teamha[teamID2].code){
                            if(strcmp(footbalista[k].post,"mohajem")==0){
                                footbalista[k].finishing=footbalista[k].finishing-10;
                            }
                        }
                    }
                }
                else if(ran==4){
                    for(int k=1;k<i;k++){
                        if(footbalista[k].codeteambazikon==teamha[teamID1].code){
                            if(strcmp(footbalista[k].post,"hafbak")==0){
                                footbalista[k].speed=(footbalista[k].speed/2);
                            }
                        }
                    }
                    for(int k=1;k<i;k++){
                        if(footbalista[k].codeteambazikon==teamha[teamID2].code){
                            if(strcmp(footbalista[k].post,"hafbak")==0){
                                footbalista[k].speed=(footbalista[k].speed/2);
                            }
                        }
                    }
                }
                long int powerofteameyek = 0, powerofteamedo = 0;
                for (int k = 1; k < 100; k++) {
                    if (footbalista[k].codeteambazikon == teamID1) {
                        powerofteameyek = powerofteameyek + footbalista[k].speed + footbalista[k].finishing +
                                          footbalista[k].defence;
                    }
                }
                for (int k = 1; k < 100; k++) {
                    if (footbalista[k].codeteambazikon == teamID2) {
                        powerofteamedo = powerofteamedo + footbalista[k].speed + footbalista[k].finishing +
                                         footbalista[k].defence;
                    }
                }
                int tedadgolhateam1=0,tedadgolhateam2=0;
                if (powerofteameyek == powerofteamedo) {
                    //cout << "the match is draw" << endl;
                    tedadgolhateam1=rand()%4+1;
                    tedadgolhateam2=tedadgolhateam1;
                    gollteam1=tedadgolhateam1;
                    gollteam2=tedadgolhateam1;
                    teamha[teamID1].emtiaz=teamha[teamID1].emtiaz+1;
                    teamha[teamID2].emtiaz=teamha[teamID2].emtiaz+1;
                    teamha[teamID1].tedad_mosavi=teamha[teamID1].tedad_mosavi+1;
                    teamha[teamID2].tedad_mosavi=teamha[teamID2].tedad_mosavi+1;
                }
                else {
                    int darsadehtemal=0;
                    if (powerofteameyek > powerofteamedo) {
                        // cout << "team " << teamID1 << " win" << endl;
                        srand(time(0));
                        darsadehtemal=rand() % 100 + 1;
                        if(0<darsadehtemal & darsadehtemal<51){
                            gollteam1=1;
                            gollteam2=0;
                            teamha[teamID1].tedadgolhaye_zadeshode=teamha[teamID1].tedadgolhaye_zadeshode+1;
                            teamha[teamID2].tedadgolhaye_khordeshode=teamha[teamID2].tedadgolhaye_khordeshode+1;
                        }
                        else if(darsadehtemal<81){
                            teamha[teamID1].tedadgolhaye_zadeshode=teamha[teamID1].tedadgolhaye_zadeshode+2;
                            gollteam1=2;
                            int x=rand()%2;
                            gollteam2=x;
                            teamha[teamID2].tedadgolhaye_zadeshode=teamha[teamID2].tedadgolhaye_zadeshode+x;
                            teamha[teamID1].tedadgolhaye_khordeshode=teamha[teamID1].tedadgolhaye_khordeshode+x;
                            teamha[teamID2].tedadgolhaye_khordeshode=teamha[teamID2].tedadgolhaye_khordeshode+2;
                        }
                        else if(darsadehtemal<96){
                            gollteam1=3;
                            teamha[teamID1].tedadgolhaye_zadeshode=teamha[teamID1].tedadgolhaye_zadeshode+3;
                            int y=rand()%3;
                            gollteam2=y;
                            teamha[teamID2].tedadgolhaye_zadeshode=teamha[teamID2].tedadgolhaye_zadeshode+y;
                            teamha[teamID1].tedadgolhaye_khordeshode=teamha[teamID1].tedadgolhaye_khordeshode+y;
                            teamha[teamID2].tedadgolhaye_khordeshode=teamha[teamID2].tedadgolhaye_khordeshode+3;
                        }
                        else if(darsadehtemal<100){
                            int z=3+rand()%20;
                            teamha[teamID1].tedadgolhaye_zadeshode=teamha[teamID1].tedadgolhaye_zadeshode+z;
                            int zz=rand()%z;
                            gollteam1=z;
                            gollteam2=zz;
                            teamha[teamID2].tedadgolhaye_zadeshode=teamha[teamID2].tedadgolhaye_zadeshode+zz;
                            teamha[teamID1].tedadgolhaye_khordeshode=teamha[teamID1].tedadgolhaye_khordeshode+zz;
                            teamha[teamID2].tedadgolhaye_khordeshode=teamha[teamID2].tedadgolhaye_khordeshode+z;

                        }
                        teamha[teamID1].emtiaz=teamha[teamID1].emtiaz+3;
                        teamha[teamID1].tedad_bord=teamha[teamID1].tedad_bord+1;
                        teamha[teamID2].tedad_bakht=teamha[teamID2].tedad_bakht+1;
                    }
                    else if (powerofteameyek < powerofteamedo) {
                        //cout << "team " << teamID2 << " win" << endl;
                        srand(time(0));
                        darsadehtemal=rand() % 100 + 1;

                        if(0<darsadehtemal & darsadehtemal<51){
                            teamha[teamID2].tedadgolhaye_zadeshode=teamha[teamID2].tedadgolhaye_zadeshode+1;
                            teamha[teamID1].tedadgolhaye_khordeshode=teamha[teamID1].tedadgolhaye_khordeshode+1;
                            gollteam2=1;
                            gollteam1=0;
                        }
                        else if(darsadehtemal<81){
                            teamha[teamID2].tedadgolhaye_zadeshode=teamha[teamID2].tedadgolhaye_zadeshode+2;
                            int x=rand()%2;
                            gollteam2=2;
                            gollteam1=x;
                            teamha[teamID1].tedadgolhaye_zadeshode=teamha[teamID1].tedadgolhaye_zadeshode+x;
                            teamha[teamID2].tedadgolhaye_khordeshode=teamha[teamID2].tedadgolhaye_khordeshode+x;
                            teamha[teamID1].tedadgolhaye_khordeshode=teamha[teamID1].tedadgolhaye_khordeshode+2;
                        }
                        else if(darsadehtemal<96){
                            teamha[teamID2].tedadgolhaye_zadeshode=teamha[teamID2].tedadgolhaye_zadeshode+3;
                            int y=rand()%3;
                            gollteam2=3;
                            gollteam1=y;
                            teamha[teamID1].tedadgolhaye_zadeshode=teamha[teamID1].tedadgolhaye_zadeshode+y;
                            teamha[teamID2].tedadgolhaye_khordeshode=teamha[teamID2].tedadgolhaye_khordeshode+y;
                            teamha[teamID1].tedadgolhaye_khordeshode=teamha[teamID1].tedadgolhaye_khordeshode+3;
                        }
                        else if(darsadehtemal<100){
                            int z=3+rand()%20;
                            teamha[teamID2].tedadgolhaye_zadeshode=teamha[teamID2].tedadgolhaye_zadeshode+z;
                            int zz=rand()%z;
                            gollteam2=z;
                            gollteam1=zz;
                            teamha[teamID1].tedadgolhaye_zadeshode=teamha[teamID1].tedadgolhaye_zadeshode+zz;
                            teamha[teamID2].tedadgolhaye_khordeshode=teamha[teamID2].tedadgolhaye_khordeshode+zz;
                            teamha[teamID1].tedadgolhaye_khordeshode=teamha[teamID1].tedadgolhaye_khordeshode+z;

                        }
                        teamha[teamID2].emtiaz=teamha[teamID2].emtiaz+3;
                        teamha[teamID2].tedad_bord=teamha[teamID2].tedad_bord+1;
                        teamha[teamID1].tedad_bakht=teamha[teamID1].tedad_bakht+1;
                    }
                }
                if(ran==2){
                    for(int k=1;k<i;k++){
                        if(footbalista[k].codeteambazikon==teamha[teamID1].code){
                            if(strcmp(footbalista[k].post,"modafe")==0){
                                footbalista[k].defence=footbalista[k].defence-footbalista[k].defence-footbalista[k].defence;
                            }
                        }
                    }
                    for(int k=1;k<i;k++){
                        if(footbalista[k].codeteambazikon==teamha[teamID2].code){
                            if(strcmp(footbalista[k].post,"modafe")==0){
                                footbalista[k].defence=footbalista[k].defence-footbalista[k].defence-footbalista[k].defence;
                            }
                        }
                    }
                }
                else if(ran==3){
                    for(int k=1;k<i;k++){
                        if(footbalista[k].codeteambazikon==teamha[teamID1].code){
                            if(strcmp(footbalista[k].post,"mohajem")==0){
                                footbalista[k].finishing=footbalista[k].finishing+10;
                            }
                        }
                    }
                    for(int k=1;k<i;k++){
                        if(footbalista[k].codeteambazikon==teamha[teamID2].code){
                            if(strcmp(footbalista[k].post,"mohajem")==0){
                                footbalista[k].finishing=footbalista[k].finishing+10;
                            }
                        }
                    }
                }
                else if(ran==4){
                    for(int k=1;k<i;k++){
                        if(footbalista[k].codeteambazikon==teamha[teamID1].code){
                            if(strcmp(footbalista[k].post,"hafbak")==0){
                                if(footbalista[k].zoj_ya_fard_boodan_sorate_hafbak==2){
                                    footbalista[k].speed=(footbalista[k].speed*2);
                                }
                                else if(footbalista[k].zoj_ya_fard_boodan_sorate_hafbak==1){
                                    footbalista[k].speed=(footbalista[k].speed*2)+1;
                                }
                            }
                        }
                    }
                    for(int k=1;k<i;k++){
                        if(footbalista[k].codeteambazikon==teamha[teamID2].code){
                            if(strcmp(footbalista[k].post,"hafbak")==0){
                                if(footbalista[k].zoj_ya_fard_boodan_sorate_hafbak==2){
                                    footbalista[k].speed=(footbalista[k].speed*2);
                                }
                                else if(footbalista[k].zoj_ya_fard_boodan_sorate_hafbak==1){
                                    footbalista[k].speed=(footbalista[k].speed*2)+1;
                                }
                            }
                        }
                    }
                }
                cout<<"the list of players of team 1: ";
                int counter=1;
                for(int k=1;k<12;k++){
                    while(footbalista[counter].codeteambazikon!=teamha[teamID1].code & counter<101){
                        counter++;
                    }
                    cout<<k<<"."<<footbalista[counter].name<<" "<<"("<<footbalista[counter].post<<")  ";
                    counter++;
                }
                cout<<endl;
                cout<<"the list of players of team 2: ";
                counter=1;
                for(int k=1;k<12;k++){
                    while(footbalista[counter].codeteambazikon!=teamha[teamID2].code & counter<101){
                        counter++;
                    }
                    cout<<k<<"."<<footbalista[counter].name<<" "<<"("<<footbalista[counter].post<<")  ";
                    counter++;
                }
                cout<<endl<<endl;
                cout<<"sharayete abohavayi : ";
                if(ran==1){
                    cout<<"abri."<<endl;
                }
                else if(ran==2){
                    cout<<"barfi."<<endl;
                }
                else if(ran==3){
                    cout<<"aftabi."<<endl;
                }
                else if(ran==4){
                    cout<<"barani."<<endl;
                }
                if(gollteam1==gollteam2){
                    cout<<"the match is draw" << endl;
                }
                else if(gollteam1>gollteam2){
                    cout << "team " << teamID1 << " win" << endl;
                }
                else if(gollteam1<gollteam2){
                    cout << "team " << teamID2 << " win" << endl;
                }
            }
        }
    }
    return 1;
}
int BeginLeague_function(int i,int j,int l){
    for(int k=0;k<j;k++){
        if(teamha[k].tedadaza==11){
            teamha[k].code_neshane_bara_takmile_11nafareboodan=1;
        }
    }
    for(int k=0;k<j-1;k++){
        if(teamha[k].code_neshane_bara_takmile_11nafareboodan==1){
            for(int m=k+1;m<j;m++){
                if(teamha[m].code_neshane_bara_takmile_11nafareboodan==1){
                    int teamID1=k,teamID2=m;
                    int adaderandom_baraye_abohava = rand()%4+1;
                    //1=abri.2=barfi.3=aftabi.4=barani.
                    match_function(i,j,adaderandom_baraye_abohava,teamID1,teamID2);
                    cout<<"*********************************"<<endl;
                }
            }
        }
    }
    for(int k=0;k<j;k++){
        if(teamha[k].code_neshane_bara_takmile_11nafareboodan==1){
            teamha[k].tafazol_golhayekhordeshode_ba_golhayezadeshode=teamha[k].tedadgolhaye_zadeshode-teamha[k].tedadgolhaye_khordeshode;
        }
    }
    cout<<"*************************************************************"<<endl;
    cout<<"<teams>"<<"\t"<<"emtiaz"<<"\t"<<"goll_z"<<"\t"<<"goll_kh"<<"\t"<<"bord"<<"\t"<<"tasavi"<<"\t"<<"bakht"<<"\t"<<"tafazol"<<endl;
    int code_team_max_emtiaz=0;
    int neshane=1;
    for(int k=1;k<j;k++){
        if(teamha[k].code_neshane_bara_takmile_11nafareboodan==1){
            int counter=0;
            for(int m=k+1;m<j;m++){
                if(teamha[m].code_neshane_bara_takmile_11nafareboodan==1){
                    counter++;
                    if(teamha[k].emtiaz>teamha[m].emtiaz){
                        code_team_max_emtiaz=k;
                    }
                    else if(teamha[k].emtiaz<teamha[m].emtiaz){
                        code_team_max_emtiaz=m;
                    }
                    else if(teamha[k].emtiaz==teamha[m].emtiaz){
                        if(teamha[k].emtiaz>code_team_max_emtiaz){
                            if(teamha[k].tafazol_golhayekhordeshode_ba_golhayezadeshode>teamha[m].tafazol_golhayekhordeshode_ba_golhayezadeshode){
                                code_team_max_emtiaz=k;
                            }
                            else if(teamha[m].tafazol_golhayekhordeshode_ba_golhayezadeshode>teamha[k].tafazol_golhayekhordeshode_ba_golhayezadeshode){
                                code_team_max_emtiaz=m;
                            }
                            else{
                                if(teamha[k].tedad_bakht<teamha[m].tedad_bakht){
                                    code_team_max_emtiaz=k;
                                }
                                else{
                                    code_team_max_emtiaz=m;
                                }
                            }
                        }
                    }
                }
            }
            if(counter==0){
                cout<<teamha[k].name<<"\t"<<teamha[k].emtiaz<<"\t"<<teamha[k].tedadgolhaye_zadeshode<<"\t";
                cout<<teamha[k].tedadgolhaye_khordeshode<<"\t"<<teamha[k].tedad_bord<<"\t"<<teamha[k].tedad_mosavi<<"\t";
                cout<<teamha[k].tedad_bakht<<"\t"<<teamha[k].tafazol_golhayekhordeshode_ba_golhayezadeshode<<endl;
                teamha[k].code_neshane_bara_takmile_11nafareboodan=0;
                return 1;
            }
            else{
                cout<<teamha[code_team_max_emtiaz].name<<"\t"<<teamha[code_team_max_emtiaz].emtiaz<<"\t"<<teamha[code_team_max_emtiaz].tedadgolhaye_zadeshode<<"\t";
                cout<<teamha[code_team_max_emtiaz].tedadgolhaye_khordeshode<<"\t"<<teamha[code_team_max_emtiaz].tedad_bord<<"\t"<<teamha[code_team_max_emtiaz].tedad_mosavi<<"\t";
                cout<<teamha[code_team_max_emtiaz].tedad_bakht<<"\t"<<teamha[code_team_max_emtiaz].tafazol_golhayekhordeshode_ba_golhayezadeshode<<endl;
                teamha[code_team_max_emtiaz].code_neshane_bara_takmile_11nafareboodan=0;
                k=0;
            }
        }
    }
}